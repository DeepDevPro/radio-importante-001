--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17 (Debian 14.17-1.pgdg120+1)
-- Dumped by pg_dump version 14.17 (Debian 14.17-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: track; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.track (
    id integer NOT NULL,
    artista character varying(100),
    titulo character varying(100),
    versao character varying(100),
    duracao_segundos integer,
    nome_arquivo character varying(200)
);


ALTER TABLE public.track OWNER TO admin;

--
-- Name: track_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.track_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.track_id_seq OWNER TO admin;

--
-- Name: track_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.track_id_seq OWNED BY public.track.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    senha_hash character varying(256) NOT NULL
);


ALTER TABLE public."user" OWNER TO admin;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO admin;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: track id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.track ALTER COLUMN id SET DEFAULT nextval('public.track_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: track; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.track (id, artista, titulo, versao, duracao_segundos, nome_arquivo) FROM stdin;
27	Clara_Hill	Run	\N	60	Clara_Hill-Run.mp3
28	Electriciety_	Daco	\N	60	Electriciety_-Daco.mp3
29	Flevans_	_Hold_no_Water	\N	60	Flevans_-_Hold_no_Water.mp3
30	Hairy_	_Bump	\N	60	Hairy_-_Bump.mp3
31	Jazza_	_Nova	\N	60	Jazza_-_Nova.mp3
32	Jazzanova_	_Lucky_Girl	\N	60	Jazzanova_-_Lucky_Girl.mp3
33	Jazzanova_	_Our_Time_is_Comming	\N	60	Jazzanova_-_Our_Time_is_Comming.mp3
34	MdCl	_Never_Never	\N	60	MdCl-_Never_Never.mp3
35	Quantic	Lead_Us_To_The_End	\N	60	Quantic-Lead_Us_To_The_End.mp3
36	Scruff	Kalimba	\N	60	Scruff-Kalimba.mp3
37	Spinna	Lasanhas	\N	60	Spinna-Lasanhas.mp3
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."user" (id, email, senha_hash) FROM stdin;
1	novo@teste.com	scrypt:32768:8:1$PpQSlKS8w1btxEHw$7fa64d43801880e1288bc0d21c5dd3820101d097d1adc25ec50c3e50b977d3f0c8d5c543ebabcefa76942b4f2233dff2d423cd3ad210b6de8baaf3055411fafa
\.


--
-- Name: track_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.track_id_seq', 37, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.user_id_seq', 1, true);


--
-- Name: track track_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT track_pkey PRIMARY KEY (id);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

